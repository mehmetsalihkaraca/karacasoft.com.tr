// Sayfa yüklendiğinde çalışacak fonksiyon
document.addEventListener('DOMContentLoaded', function() {
    
    // Navbar scroll efekti
    const navbar = document.querySelector('.navbar');
    window.addEventListener('scroll', function() {
        if (window.scrollY > 50) {
            navbar.classList.add('scrolled');
        } else {
            navbar.classList.remove('scrolled');
        }
    });
    
    // Back to top butonu
    const backToTopButton = document.querySelector('.back-to-top');
    window.addEventListener('scroll', function() {
        if (window.scrollY > 300) {
            backToTopButton.classList.add('active');
        } else {
            backToTopButton.classList.remove('active');
        }
    });
    
    // Scroll animasyonları
    const animateElements = document.querySelectorAll('.animate-on-scroll');
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                // Gecikme süresini al
                const delay = entry.target.getAttribute('data-delay') || 0;
                
                // Belirtilen gecikme süresi kadar bekleyip animasyonu uygula
                setTimeout(() => {
                    entry.target.classList.add('animated');
                }, delay * 1000);
                
                observer.unobserve(entry.target);
            }
        });
    }, {
        threshold: 0.1,
        rootMargin: '0px 0px -100px 0px'
    });
    
    animateElements.forEach(element => {
        observer.observe(element);
    });
    
    // Skill bar animasyonları
    const skillBars = document.querySelectorAll('.skill-progress');
    const skillObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const width = entry.target.getAttribute('data-width');
                entry.target.style.width = width + '%';
                skillObserver.unobserve(entry.target);
            }
        });
    }, {
        threshold: 0.5
    });
    
    skillBars.forEach(bar => {
        skillObserver.observe(bar);
    });
    
    // Portfolio filtreleme
    const filterButtons = document.querySelectorAll('.filter-btn');
    const portfolioItems = document.querySelectorAll('.portfolio-item');
    
    filterButtons.forEach(button => {
        button.addEventListener('click', function() {
            // Aktif butonu değiştir
            filterButtons.forEach(btn => btn.classList.remove('active'));
            this.classList.add('active');
            
            const filterValue = this.getAttribute('data-filter');
            
            portfolioItems.forEach(item => {
                if (filterValue === 'all' || item.getAttribute('data-category') === filterValue) {
                    item.style.display = 'block';
                    setTimeout(() => {
                        item.style.opacity = '1';
                        item.style.transform = 'scale(1)';
                    }, 100);
                } else {
                    item.style.opacity = '0';
                    item.style.transform = 'scale(0.8)';
                    setTimeout(() => {
                        item.style.display = 'none';
                    }, 300);
                }
            });
        });
    });
    
    // Navbar link tıklamaları
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => {
        link.addEventListener('click', function() {
            navLinks.forEach(l => l.classList.remove('active'));
            this.classList.add('active');
        });
    });
    
    // Smooth scroll for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('href');
            if (targetId === '#') return;
            
            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                window.scrollTo({
                    top: targetElement.offsetTop - 80,
                    behavior: 'smooth'
                });
            }
        });
    });
});


// Gelişmiş Arama Sistemi - Tüm Sayfayı Otomatik Tarar
document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.getElementById('searchInput');
    const searchResults = document.getElementById('searchResults');
    
    if (!searchInput || !searchResults) return;
    
    let searchIndex = [];
    
    // Sayfa yüklendiğinde tüm içeriği otomatik indexle
    function buildSearchIndex() {
        searchIndex = [];
        
        // Taranacak alanları belirle (header, footer hariç ana içerik)
        const searchableAreas = document.querySelectorAll('section, article, .content, main, .blog-post, .portfolio-item');
        
        searchableAreas.forEach((area, areaIndex) => {
            // Section başlığını al
            const sectionTitle = area.querySelector('h1, h2, h3')?.textContent.trim() || 
                                area.getAttribute('id') || 
                                `Bölüm ${areaIndex + 1}`;
            
            const sectionId = area.getAttribute('id') || `section-${areaIndex}`;
            
            // Tüm metin içeriklerini al (başlıklar, paragraflar, listeler vs)
            const textElements = area.querySelectorAll('h1, h2, h3, h4, h5, h6, p, li, span, a, .card-title, .card-text, .skill-name, .blog-title');
            
            textElements.forEach(element => {
                const text = element.textContent.trim();
                if (text.length > 2) { // Çok kısa metinleri atla
                    // Her kelimeyi ayrı ayrı indexle
                    const words = text.split(/\s+/);
                    words.forEach(word => {
                        if (word.length > 2) {
                            searchIndex.push({
                                word: word.toLowerCase(),
                                fullText: text,
                                section: sectionTitle,
                                element: `#${sectionId}`,
                                elementType: element.tagName,
                                priority: getPriority(element.tagName)
                            });
                        }
                    });
                    
                    // Tam cümleyi de ekle
                    searchIndex.push({
                        word: text.toLowerCase(),
                        fullText: text,
                        section: sectionTitle,
                        element: `#${sectionId}`,
                        elementType: element.tagName,
                        priority: getPriority(element.tagName)
                    });
                }
            });
        });
        
        // console.log(`${searchIndex.length} adet içerik indexlendi`);
    }
    
    // Öncelik belirle (başlıklar daha önemli)
    function getPriority(tagName) {
        const priorities = {
            'H1': 10, 'H2': 9, 'H3': 8, 'H4': 7,
            'TITLE': 10, 'A': 6, 'STRONG': 6,
            'P': 5, 'LI': 4, 'SPAN': 3
        };
        return priorities[tagName] || 1;
    }
    
    // Vurgulama fonksiyonu
    function highlightMatch(text, searchTerm) {
        const regex = new RegExp(`(${escapeRegex(searchTerm)})`, 'gi');
        return text.replace(regex, '<mark>$1</mark>');
    }
    
    // Regex özel karakterlerini escape et
    function escapeRegex(str) {
        return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    }
    
    // Arama fonksiyonu
    searchInput.addEventListener('input', function(e) {
        const searchTerm = e.target.value.toLowerCase().trim();
        
        if (searchTerm.length < 2) {
            searchResults.classList.remove('active');
            searchResults.innerHTML = '';
            return;
        }
        
        // Eşleşen sonuçları bul
        let results = searchIndex.filter(item => 
            item.word.includes(searchTerm)
        );
        
        // Tekrar edenleri temizle ve önceliğe göre sırala
        const uniqueResults = [];
        const seenTexts = new Set();
        
        results
            .sort((a, b) => b.priority - a.priority)
            .forEach(item => {
                const key = `${item.fullText}-${item.section}`;
                if (!seenTexts.has(key)) {
                    seenTexts.add(key);
                    uniqueResults.push(item);
                }
            });
        
        // En fazla 10 sonuç göster
        const topResults = uniqueResults.slice(0, 10);
        
        if (topResults.length > 0) {
            searchResults.innerHTML = topResults.map(result => {
                // Uzun metinleri kısalt
                let displayText = result.fullText;
                if (displayText.length > 60) {
                    const index = displayText.toLowerCase().indexOf(searchTerm);
                    if (index !== -1) {
                        const start = Math.max(0, index - 20);
                        const end = Math.min(displayText.length, index + searchTerm.length + 40);
                        displayText = (start > 0 ? '...' : '') + 
                                    displayText.substring(start, end) + 
                                    (end < displayText.length ? '...' : '');
                    } else {
                        displayText = displayText.substring(0, 60) + '...';
                    }
                }
                
                return `
                    <div class="search-result-item" data-target="${result.element}">
                        <div class="search-result-text">${highlightMatch(displayText, searchTerm)}</div>
                        <div class="search-result-section">
                            <i class="fas fa-bookmark"></i> ${result.section}
                        </div>
                    </div>
                `;
            }).join('');
            
            searchResults.innerHTML += `
                <div class="search-result-footer">
                    ${topResults.length} sonuç bulundu
                </div>
            `;
            
            searchResults.classList.add('active');
            
            // Tıklama olaylarını ekle
            document.querySelectorAll('.search-result-item').forEach(item => {
                item.addEventListener('click', function() {
                    const target = this.getAttribute('data-target');
                    const targetElement = document.querySelector(target);
                    if (targetElement) {
                        targetElement.scrollIntoView({
                            behavior: 'smooth',
                            block: 'start'
                        });
                        
                        // Hedef elementi vurgula
                        targetElement.style.transition = 'background-color 0.5s';
                        targetElement.style.backgroundColor = 'rgba(255, 193, 7, 0.2)';
                        setTimeout(() => {
                            targetElement.style.backgroundColor = '';
                        }, 2000);
                    }
                    
                    searchInput.value = '';
                    searchResults.classList.remove('active');
                    searchResults.innerHTML = '';
                });
            });
        } else {
            searchResults.innerHTML = `
                <div class="search-no-results">
                    <i class="fas fa-search"></i>
                    <p>"${searchTerm}" için sonuç bulunamadı</p>
                </div>
            `;
            searchResults.classList.add('active');
        }
    });
    
    // Dışarı tıklandığında kapat
    document.addEventListener('click', function(e) {
        if (!searchInput.contains(e.target) && !searchResults.contains(e.target)) {
            searchResults.classList.remove('active');
        }
    });
    
    // ESC tuşu ile kapat
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            searchResults.classList.remove('active');
            searchResults.innerHTML = '';
            searchInput.value = '';
            searchInput.blur();
        }
    });
    
    // Sayfa yüklendiğinde indexi oluştur
    buildSearchIndex();
    
    // MutationObserver ile dinamik içerik değişikliklerini izle
    // (Yeni blog yazısı eklendiğinde otomatik yeniden indexler)
    const observer = new MutationObserver(function(mutations) {
        mutations.forEach(function(mutation) {
            if (mutation.addedNodes.length > 0) {
                console.log('Yeni içerik eklendi, index yenileniyor...');
                buildSearchIndex();
            }
        });
    });
    
    // Ana içerik alanını izle
    const mainContent = document.querySelector('main') || document.body;
    observer.observe(mainContent, {
        childList: true,
        subtree: true
    });
});

// Dark Mode Toggle (localStorage kullanmadan)
document.addEventListener('DOMContentLoaded', function() {
    const themeToggle = document.getElementById('themeToggle');
    
    if (!themeToggle) return;
    
    const body = document.body;
    const icon = themeToggle.querySelector('i');
    
    // Sayfa yüklendiğinde tema tercihini kontrol et (cookie veya başka yöntemle)
    const isDark = document.cookie.includes('theme=dark');
    if (isDark) {
        body.classList.add('dark-mode');
        if (icon) {
            icon.classList.remove('fa-moon');
            icon.classList.add('fa-sun');
        }
    }
    
    themeToggle.addEventListener('click', function() {
        body.classList.toggle('dark-mode');
        
        if (body.classList.contains('dark-mode')) {
            if (icon) {
                icon.classList.remove('fa-moon');
                icon.classList.add('fa-sun');
            }
            document.cookie = 'theme=dark; path=/; max-age=31536000';
        } else {
            if (icon) {
                icon.classList.remove('fa-sun');
                icon.classList.add('fa-moon');
            }
            document.cookie = 'theme=light; path=/; max-age=31536000';
        }
    });
});



/* Certificate Popup Functions */
function openCertModal(src, title) {
    const modal = document.getElementById("certModal");
    const modalImg = document.getElementById("certImg");
    const captionText = document.getElementById("certCaption");
    
    modal.style.display = "block";
    modalImg.src = src;
    captionText.innerHTML = title;
    
    // Sayfa kaymasını engelle
    document.body.style.overflow = "hidden";
}

function closeCertModal() {
    const modal = document.getElementById("certModal");
    modal.style.display = "none";
    
    // Kaymayı geri aç
    document.body.style.overflow = "auto";
}

// ESC tuşu ile kapatma
document.addEventListener('keydown', function(event) {
    if (event.key === "Escape") {
        closeCertModal();
    }
});

// Sayfa yüklendiği anda çalışacak ana fonksiyon
document.addEventListener("DOMContentLoaded", function() {
    initCookieConsent();
});



// gdpr 



/**
 * Cookie Consent Manager - karaca_soft
 * Tüm tracking scriptleri type="text/plain" class="analytics-script" olarak işaretlenmeli
 */

(function () {
    const STORAGE_KEY = 'karaca_soft_cookies';

    /* ─── Yardımcı: Tercihleri oku ─── */
    function getPrefs() {
        try {
            const raw = localStorage.getItem(STORAGE_KEY);
            return raw ? JSON.parse(raw) : null;
        } catch (e) {
            return null;
        }
    }

    /* ─── Yardımcı: Tercihleri kaydet ─── */
    function savePrefs(prefs) {
        prefs.date = new Date().toISOString();
        localStorage.setItem(STORAGE_KEY, JSON.stringify(prefs));
    }

    /* ─── Tracking scriptlerini DOM'a ekle ─── */
    function loadTrackingScripts() {
        document.querySelectorAll('script.analytics-script').forEach(function (el) {
            if (el.getAttribute('data-loaded') === 'true') return;

            var newScript = document.createElement('script');
            newScript.type = 'text/javascript';

            var src = el.getAttribute('src'); // getAttribute zorunlu!
            if (src) {
                newScript.src = src;
                newScript.async = true;
            } else {
                newScript.textContent = el.textContent;
            }

            el.setAttribute('data-loaded', 'true'); // orijinali işaretle
            document.head.appendChild(newScript);
        });
        console.log('[CookieConsent] Tracking scriptler yüklendi.');
    }

    /* ─── UI: Paneli aç/kapat ─── */
    function showPanel() {
        var panel = document.getElementById('cookie-consent');
        var trigger = document.getElementById('cookie-trigger');
        if (panel) panel.classList.add('active');
        if (trigger) trigger.classList.remove('visible');
    }

    function hidePanel() {
        var panel = document.getElementById('cookie-consent');
        var trigger = document.getElementById('cookie-trigger');
        if (panel) panel.classList.remove('active');
        if (trigger) trigger.classList.add('visible');
    }

    /* ─── UI: Checkbox'ları güncelle ─── */
    function syncCheckboxes(prefs) {
        var analyticsBox = document.getElementById('opt-analytics');
        if (analyticsBox && prefs) {
            analyticsBox.checked = !!prefs.analytics;
        }
    }

    /* ─── Başlangıç ─── */
    function init() {
        var prefs = getPrefs();

        if (!prefs) {
            // İlk ziyaret → paneli göster
            setTimeout(showPanel, 800);
        } else {
            // Daha önce seçim yapılmış
            syncCheckboxes(prefs);
            hidePanel();
            if (prefs.analytics) {
                loadTrackingScripts();
            }
        }
    }

    /* ══════════════════════════════════════
       PUBLIC FONKSİYONLAR (HTML onclick için)
    ══════════════════════════════════════ */

    /** Hepsini Kabul Et */
    window.acceptAllCookies = function () {
        savePrefs({ essential: true, analytics: true });
        hidePanel();
        loadTrackingScripts();
    };

    /** Reddet (sadece zorunlu) */
    window.rejectAllCookies = function () {
        savePrefs({ essential: true, analytics: false });
        hidePanel();
        // Tracking scriptler yüklenmez
    };

    /** Seçimi Kaydet */
    window.saveCookiePreferences = function () {
        var analyticsBox = document.getElementById('opt-analytics');
        var analyticsChecked = analyticsBox ? analyticsBox.checked : false;

        savePrefs({ essential: true, analytics: analyticsChecked });
        hidePanel();

        if (analyticsChecked) {
            loadTrackingScripts();
        }
    };

    /** Küçük ikon tıklaması → paneli aç/kapat */
    window.toggleCookiePanel = function () {
        var panel = document.getElementById('cookie-consent');
        if (!panel) return;
        if (panel.classList.contains('active')) {
            hidePanel();
        } else {
            showPanel();
        }
    };

    /* ─── DOM hazır olunca başlat ─── */
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init(); // DOMContentLoaded zaten geçti
    }

})();


